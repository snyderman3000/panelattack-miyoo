local system = require("client.src.system")
local DebugSettings = require("client.src.debug.DebugSettings")
local logger = require("common.lib.logger")
---@diagnostic disable: duplicate-set-field

-- Put any local development changes you need in here that you don't want commited.

---@param threshold integer? the discard threshold in seconds
local function enableProfiler(threshold)
  local prof = require("common.lib.zoneProfiler")
  prof.enable(true)
  prof.setDurationFilter((threshold or DebugSettings.getProfileThreshold()) / 1000)
end

local developerTools = {}

function developerTools.processArgs(args)
  for _, value in pairs(args) do
    if value == "debug" then
      system.startDebugger()
    elseif value == "profileFrameTimes" then
      enableProfiler()

      if not collectgarbage("isrunning") then
        collectgarbage("restart")
      end
    elseif value == "profileMemory" then
      enableProfiler(0)
      -- the garbage collector is a primary source of frame spikes
      -- thus one goal of profiling is to identify where memory is allocated
      -- because the less memory is allocated, the less the garbage collector runs 
      -- the final goal would be to achieve near 0 memory allocation during games
      -- this would allow us to simply turn off the GC during matches and only collect afterwards
      PROFILE_MEMORY = true
      collectgarbage("stop")
    elseif value == "updaterTest" then
      -- drop the updater directory of the updater in for debugging purposes
      GAME_UPDATER_STATES = { idle = 0, checkingForUpdates = 1, downloading = 2}
      GAME_UPDATER = require("updater.gameUpdater")
    else
      for match in string.gmatch(value, "user%-id=(.*)") do
        developerTools.customUserID = match
      end
      for match in string.gmatch(value, "username=(.*)") do
        developerTools.customUsername = match
      end
    end
  end
end

local realId = nil
local realName = nil

function developerTools.wrapUsernameConfig(customUsername)
  assert(customUsername)

  local read = readConfigFile
  local write = write_conf_file

  readConfigFile = function(c)
    ---@type UserConfig
    c = read(c)
    realName = c.name
    logger.debug("Original username was " .. realName)
    c.name = customUsername
    logger.debug("Overwriting name to custom username: " .. c.name)
  end

  write_conf_file = function()
    if config.name == customUsername then
      assert(realName)
      config.name = realName
    end
    write()
    config.name = customUsername
  end
end

function developerTools.wrapUserIDRead(customUserID)
  assert(customUserID)

  logger.debug("Overwriting userID with command line argument")

  local save = require("client.src.save")
  local readId = save.read_user_id_file
  save.read_user_id_file = function(serverIP)
    realId = readId(serverIP)
    return customUserID
  end

  local writeId = save.write_user_id_file
  save.write_user_id_file = function(userID, serverIP)
    if userID == customUserID then
      userID = realId
    end
    assert(userID ~= nil)
    writeId(userID, serverIP)
  end
end

developerTools.processArgs(arg)
if developerTools.customUsername then
  developerTools.wrapUsernameConfig(developerTools.customUsername)
end
if developerTools.customUserID then
  developerTools.wrapUserIDRead(developerTools.customUserID)
end

return developerTools