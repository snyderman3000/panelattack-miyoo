local GameBase = require("client.src.scenes.GameBase")
local class = require("common.lib.class")
local GameModes = require("common.data.GameModes")

-- Scene for an endless mode instance of the game
local EndlessGame = class(
  function (self, sceneParams)
  end,
  GameBase
)

EndlessGame.name = "EndlessGame"

function EndlessGame:customLoad()
  self.match:connectSignal("matchEnded", self, self.onMatchEnded)
end

---@param match ClientMatch
function EndlessGame:onMatchEnded(match)
  if match.players[1].stack.difficulty then
    GAME.scores:saveEndlessScoreForLevel(match.players[1].stack.engine.score, match.players[1].stack.difficulty)
  end
end

return EndlessGame