--[[
A plugin for the language server to resolve the import libraries requires
Intellisense becomes available for the returned types despite them technically being just a lua function call

MIT License

Copyright (c) 2024 Elmārs Āboliņš, including code from Justin van der Leij

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
]]

local workspace = require "workspace"

local function extractPathComponents(path)
    local components = {}
    for component in path:gmatch("[^/]+") do
        table.insert(components, component)
    end

    return components
end

local import = function(path, fileUri)
    local callerPath = fileUri

    local pathStack = {}

    if (path:sub(1, 1) == ".") then
        local components = extractPathComponents(callerPath)

        for i = 1, #components - 1 do
            pathStack[i] = components[i]
        end
    end

    local components = extractPathComponents(path)

    for _, component in ipairs(components) do
        if (component == ".") then
            -- Skip
        elseif (component == "..") then
            table.remove(pathStack, #pathStack)
        else
            table.insert(pathStack, component)
        end
    end

    local out = table.concat(pathStack, ".")

    return "require(\""..out.."\")"
end

function OnSetText(uri, text)
    local diffs = {}

    local transformedUri = uri:sub(#workspace.rootUri+2)

    for startPos, path, finish in text:gmatch '()import%(([^%(%)]+)%)()' do
        diffs[#diffs+1] = {
            start  = startPos,
            finish = finish - 1,
            text   = import(path:gsub('\"',""), transformedUri),
        }
    end

    return diffs
end